import OpenAI from "openai";
import { NextRequest } from "next/server";
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
const MODEL=process.env.ASTRAX_MODEL||"gpt-5.6-luna";
export async function POST(req:NextRequest){
 try{
  if(!process.env.OPENAI_API_KEY) return new Response("OPENAI_API_KEY is not configured",{status:500});
  const {messages}=await req.json();
  if(!Array.isArray(messages)) return new Response("Invalid messages",{status:400});
  const stream=await client.responses.create({model:MODEL,input:messages,stream:true});
  const encoder=new TextEncoder();
  const body=new ReadableStream({async start(controller){
   try{for await(const event of stream as any){if(event.type==="response.output_text.delta")controller.enqueue(encoder.encode(event.delta));}controller.close();}
   catch(e){controller.error(e)}
  }});
  return new Response(body,{headers:{"content-type":"text/plain; charset=utf-8","cache-control":"no-cache"}});
 }catch(e){return new Response(e instanceof Error?e.message:"Server error",{status:500})}
}